package com.example.instrument;

import java.util.List;

public class MarketAndDistribution {
    private List<AlternateMarketIdentifier> alternateMarketIdentifiers;
    private List<Distribution> distributions;

    public List<AlternateMarketIdentifier> getAlternateMarketIdentifiers() { return alternateMarketIdentifiers; }
    public void setAlternateMarketIdentifiers(List<AlternateMarketIdentifier> alternateMarketIdentifiers) { this.alternateMarketIdentifiers = alternateMarketIdentifiers; }
    public List<Distribution> getDistributions() { return distributions; }
    public void setDistributions(List<Distribution> distributions) { this.distributions = distributions; }
}
