package com.example.instrument;

public class ExtraAttributes {
    private Integer interestRateBasis;
    private String uniqueInstrumentKey;
    private Integer approved;
    private String tpSystemCode;
    private Integer sanctioned;
    private String maturityType;
    private String calculationTypeDescription;
    private String firstSettlementDate;
    private String basicSpread;
    private String benchmarkMultiplier;
    private String callFeature;
    private Integer perpetual;
    private String calcMaturity;
    private Integer deferredInterestPayment;
    private String offerStartDate;
    private String dirtyCleanPrice;
    private Integer quoteType;
    private String ultimateParentIssuer;
    private Integer region;
    private Integer oldProductType;
    private Integer usSecurity;
    private String previousCouponDate;
    private String nextCouponDate;
    private Integer extendable;
    private Double yield;
    private Double yieldToCall;
    private Integer minimumInvestmentAmount;
    private Double bidYield;
    private String tradeCurrency;
    private Integer percentageParQuoted;
    private String couponType;

    public Integer getInterestRateBasis() { return interestRateBasis; }
    public void setInterestRateBasis(Integer interestRateBasis) { this.interestRateBasis = interestRateBasis; }
    public String getUniqueInstrumentKey() { return uniqueInstrumentKey; }
    public void setUniqueInstrumentKey(String uniqueInstrumentKey) { this.uniqueInstrumentKey = uniqueInstrumentKey; }
    public Integer getApproved() { return approved; }
    public void setApproved(Integer approved) { this.approved = approved; }
    public String getTpSystemCode() { return tpSystemCode; }
    public void setTpSystemCode(String tpSystemCode) { this.tpSystemCode = tpSystemCode; }
    public Integer getSanctioned() { return sanctioned; }
    public void setSanctioned(Integer sanctioned) { this.sanctioned = sanctioned; }
    public String getMaturityType() { return maturityType; }
    public void setMaturityType(String maturityType) { this.maturityType = maturityType; }
    public String getCalculationTypeDescription() { return calculationTypeDescription; }
    public void setCalculationTypeDescription(String calculationTypeDescription) { this.calculationTypeDescription = calculationTypeDescription; }
    public String getFirstSettlementDate() { return firstSettlementDate; }
    public void setFirstSettlementDate(String firstSettlementDate) { this.firstSettlementDate = firstSettlementDate; }
    public String getBasicSpread() { return basicSpread; }
    public void setBasicSpread(String basicSpread) { this.basicSpread = basicSpread; }
    public String getBenchmarkMultiplier() { return benchmarkMultiplier; }
    public void setBenchmarkMultiplier(String benchmarkMultiplier) { this.benchmarkMultiplier = benchmarkMultiplier; }
    public String getCallFeature() { return callFeature; }
    public void setCallFeature(String callFeature) { this.callFeature = callFeature; }
    public Integer getPerpetual() { return perpetual; }
    public void setPerpetual(Integer perpetual) { this.perpetual = perpetual; }
    public String getCalcMaturity() { return calcMaturity; }
    public void setCalcMaturity(String calcMaturity) { this.calcMaturity = calcMaturity; }
    public Integer getDeferredInterestPayment() { return deferredInterestPayment; }
    public void setDeferredInterestPayment(Integer deferredInterestPayment) { this.deferredInterestPayment = deferredInterestPayment; }
    public String getOfferStartDate() { return offerStartDate; }
    public void setOfferStartDate(String offerStartDate) { this.offerStartDate = offerStartDate; }
    public String getDirtyCleanPrice() { return dirtyCleanPrice; }
    public void setDirtyCleanPrice(String dirtyCleanPrice) { this.dirtyCleanPrice = dirtyCleanPrice; }
    public Integer getQuoteType() { return quoteType; }
    public void setQuoteType(Integer quoteType) { this.quoteType = quoteType; }
    public String getUltimateParentIssuer() { return ultimateParentIssuer; }
    public void setUltimateParentIssuer(String ultimateParentIssuer) { this.ultimateParentIssuer = ultimateParentIssuer; }
    public Integer getRegion() { return region; }
    public void setRegion(Integer region) { this.region = region; }
    public Integer getOldProductType() { return oldProductType; }
    public void setOldProductType(Integer oldProductType) { this.oldProductType = oldProductType; }
    public Integer getUsSecurity() { return usSecurity; }
    public void setUsSecurity(Integer usSecurity) { this.usSecurity = usSecurity; }
    public String getPreviousCouponDate() { return previousCouponDate; }
    public void setPreviousCouponDate(String previousCouponDate) { this.previousCouponDate = previousCouponDate; }
    public String getNextCouponDate() { return nextCouponDate; }
    public void setNextCouponDate(String nextCouponDate) { this.nextCouponDate = nextCouponDate; }
    public Integer getExtendable() { return extendable; }
    public void setExtendable(Integer extendable) { this.extendable = extendable; }
    public Double getYield() { return yield; }
    public void setYield(Double yield) { this.yield = yield; }
    public Double getYieldToCall() { return yieldToCall; }
    public void setYieldToCall(Double yieldToCall) { this.yieldToCall = yieldToCall; }
    public Integer getMinimumInvestmentAmount() { return minimumInvestmentAmount; }
    public void setMinimumInvestmentAmount(Integer minimumInvestmentAmount) { this.minimumInvestmentAmount = minimumInvestmentAmount; }
    public Double getBidYield() { return bidYield; }
    public void setBidYield(Double bidYield) { this.bidYield = bidYield; }
    public String getTradeCurrency() { return tradeCurrency; }
    public void setTradeCurrency(String tradeCurrency) { this.tradeCurrency = tradeCurrency; }
    public Integer getPercentageParQuoted() { return percentageParQuoted; }
    public void setPercentageParQuoted(Integer percentageParQuoted) { this.percentageParQuoted = percentageParQuoted; }
    public String getCouponType() { return couponType; }
    public void setCouponType(String couponType) { this.couponType = couponType; }
}
