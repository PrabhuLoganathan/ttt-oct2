package com.example.instrument;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;

public class Main {
    public static void main(String[] args) throws Exception {
        ObjectMapper mapper = new ObjectMapper()
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        File json = new File("instrument_FR0014006IX6.json");
        InstrumentResponse resp = mapper.readValue(json, InstrumentResponse.class);
        System.out.println("ISIN: " + resp.getData().getAttributes().getIsinNumber());
        System.out.println("Issuer name: " + resp.getData().getAttributes()
                .getPricingAndIssuer().getIssuer().get(0).getIssuerName());
    }
}
