package com.example.instrument;

public class Price {
    private Double lastPrice;
    private String lastPriceDate;
    private String lastPriceValid;
    private String priceSource;
    private String priceType;
    private String priceCurrency;
    private Integer priceFactor;
    private Integer parValue;

    public Double getLastPrice() { return lastPrice; }
    public void setLastPrice(Double lastPrice) { this.lastPrice = lastPrice; }
    public String getLastPriceDate() { return lastPriceDate; }
    public void setLastPriceDate(String lastPriceDate) { this.lastPriceDate = lastPriceDate; }
    public String getLastPriceValid() { return lastPriceValid; }
    public void setLastPriceValid(String lastPriceValid) { this.lastPriceValid = lastPriceValid; }
    public String getPriceSource() { return priceSource; }
    public void setPriceSource(String priceSource) { this.priceSource = priceSource; }
    public String getPriceType() { return priceType; }
    public void setPriceType(String priceType) { this.priceType = priceType; }
    public String getPriceCurrency() { return priceCurrency; }
    public void setPriceCurrency(String priceCurrency) { this.priceCurrency = priceCurrency; }
    public Integer getPriceFactor() { return priceFactor; }
    public void setPriceFactor(Integer priceFactor) { this.priceFactor = priceFactor; }
    public Integer getParValue() { return parValue; }
    public void setParValue(Integer parValue) { this.parValue = parValue; }
}
