package com.example.instrument;

import java.util.List;

public class RiskAndRating {
    private String ultimateParentInstitution;
    private String fundHouseName;
    private String issueDate;
    private Integer status;
    private String currency;
    private String riskCountry;
    private String concentrationCheckIssuer;
    private String concentrationCheckIssuerName;
    private String concentrationCheckRiskCountry;
    private String bbIssuerDomicile;
    private List<Risk> risk;
    private List<Rating> rating;

    public String getUltimateParentInstitution() { return ultimateParentInstitution; }
    public void setUltimateParentInstitution(String ultimateParentInstitution) { this.ultimateParentInstitution = ultimateParentInstitution; }
    public String getFundHouseName() { return fundHouseName; }
    public void setFundHouseName(String fundHouseName) { this.fundHouseName = fundHouseName; }
    public String getIssueDate() { return issueDate; }
    public void setIssueDate(String issueDate) { this.issueDate = issueDate; }
    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public String getRiskCountry() { return riskCountry; }
    public void setRiskCountry(String riskCountry) { this.riskCountry = riskCountry; }
    public String getConcentrationCheckIssuer() { return concentrationCheckIssuer; }
    public void setConcentrationCheckIssuer(String concentrationCheckIssuer) { this.concentrationCheckIssuer = concentrationCheckIssuer; }
    public String getConcentrationCheckIssuerName() { return concentrationCheckIssuerName; }
    public void setConcentrationCheckIssuerName(String concentrationCheckIssuerName) { this.concentrationCheckIssuerName = concentrationCheckIssuerName; }
    public String getConcentrationCheckRiskCountry() { return concentrationCheckRiskCountry; }
    public void setConcentrationCheckRiskCountry(String concentrationCheckRiskCountry) { this.concentrationCheckRiskCountry = concentrationCheckRiskCountry; }
    public String getBbIssuerDomicile() { return bbIssuerDomicile; }
    public void setBbIssuerDomicile(String bbIssuerDomicile) { this.bbIssuerDomicile = bbIssuerDomicile; }
    public List<Risk> getRisk() { return risk; }
    public void setRisk(List<Risk> risk) { this.risk = risk; }
    public List<Rating> getRating() { return rating; }
    public void setRating(List<Rating> rating) { this.rating = rating; }
}
