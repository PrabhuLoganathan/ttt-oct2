package com.example.instrument;

import java.util.List;

public class InstrumentResponse {
    private Data data;

    public Data getData() { return data; }
    public void setData(Data data) { this.data = data; }
}
