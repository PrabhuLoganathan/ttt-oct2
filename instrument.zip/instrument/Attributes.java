package com.example.instrument;

import java.util.List;

public class Attributes {
    private String isinNumber;
    private Integer productRiskRating;
    private Integer productGroup;
    private Integer product;
    private Integer status;
    private Integer instrumentType;
    private Integer instrumentNature;
    private String securityCurrency;
    private String simpleChineseName;
    private String traditionalChineseName;
    private Integer subType;
    private Integer coupon;
    private String couponPaymentFrequency;
    private String firstCouponDate;
    private String bloombergTicker;
    private String denomination;
    private String productCreationDate;
    private String redemptionCurrency;
    private Integer redemptionQuote;
    private Integer sector;
    private Long amountIssued;
    private String industryGroup;
    private String longName;
    private String shortName;
    private String bondGeography;

    private ExtraAttributes extraAttributes;
    private AdditionalAttributes additionalAttributes;
    private PricingAndIssuer pricingAndIssuer;
    private RiskAndRating riskAndRating;
    private MarketAndDistribution marketAndDistribution;
    private List<Segment> segments;

    public String getIsinNumber() { return isinNumber; }
    public void setIsinNumber(String isinNumber) { this.isinNumber = isinNumber; }
    public Integer getProductRiskRating() { return productRiskRating; }
    public void setProductRiskRating(Integer productRiskRating) { this.productRiskRating = productRiskRating; }
    public Integer getProductGroup() { return productGroup; }
    public void setProductGroup(Integer productGroup) { this.productGroup = productGroup; }
    public Integer getProduct() { return product; }
    public void setProduct(Integer product) { this.product = product; }
    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }
    public Integer getInstrumentType() { return instrumentType; }
    public void setInstrumentType(Integer instrumentType) { this.instrumentType = instrumentType; }
    public Integer getInstrumentNature() { return instrumentNature; }
    public void setInstrumentNature(Integer instrumentNature) { this.instrumentNature = instrumentNature; }
    public String getSecurityCurrency() { return securityCurrency; }
    public void setSecurityCurrency(String securityCurrency) { this.securityCurrency = securityCurrency; }
    public String getSimpleChineseName() { return simpleChineseName; }
    public void setSimpleChineseName(String simpleChineseName) { this.simpleChineseName = simpleChineseName; }
    public String getTraditionalChineseName() { return traditionalChineseName; }
    public void setTraditionalChineseName(String traditionalChineseName) { this.traditionalChineseName = traditionalChineseName; }
    public Integer getSubType() { return subType; }
    public void setSubType(Integer subType) { this.subType = subType; }
    public Integer getCoupon() { return coupon; }
    public void setCoupon(Integer coupon) { this.coupon = coupon; }
    public String getCouponPaymentFrequency() { return couponPaymentFrequency; }
    public void setCouponPaymentFrequency(String couponPaymentFrequency) { this.couponPaymentFrequency = couponPaymentFrequency; }
    public String getFirstCouponDate() { return firstCouponDate; }
    public void setFirstCouponDate(String firstCouponDate) { this.firstCouponDate = firstCouponDate; }
    public String getBloombergTicker() { return bloombergTicker; }
    public void setBloombergTicker(String bloombergTicker) { this.bloombergTicker = bloombergTicker; }
    public String getDenomination() { return denomination; }
    public void setDenomination(String denomination) { this.denomination = denomination; }
    public String getProductCreationDate() { return productCreationDate; }
    public void setProductCreationDate(String productCreationDate) { this.productCreationDate = productCreationDate; }
    public String getRedemptionCurrency() { return redemptionCurrency; }
    public void setRedemptionCurrency(String redemptionCurrency) { this.redemptionCurrency = redemptionCurrency; }
    public Integer getRedemptionQuote() { return redemptionQuote; }
    public void setRedemptionQuote(Integer redemptionQuote) { this.redemptionQuote = redemptionQuote; }
    public Integer getSector() { return sector; }
    public void setSector(Integer sector) { this.sector = sector; }
    public Long getAmountIssued() { return amountIssued; }
    public void setAmountIssued(Long amountIssued) { this.amountIssued = amountIssued; }
    public String getIndustryGroup() { return industryGroup; }
    public void setIndustryGroup(String industryGroup) { this.industryGroup = industryGroup; }
    public String getLongName() { return longName; }
    public void setLongName(String longName) { this.longName = longName; }
    public String getShortName() { return shortName; }
    public void setShortName(String shortName) { this.shortName = shortName; }
    public String getBondGeography() { return bondGeography; }
    public void setBondGeography(String bondGeography) { this.bondGeography = bondGeography; }

    public ExtraAttributes getExtraAttributes() { return extraAttributes; }
    public void setExtraAttributes(ExtraAttributes extraAttributes) { this.extraAttributes = extraAttributes; }
    public AdditionalAttributes getAdditionalAttributes() { return additionalAttributes; }
    public void setAdditionalAttributes(AdditionalAttributes additionalAttributes) { this.additionalAttributes = additionalAttributes; }
    public PricingAndIssuer getPricingAndIssuer() { return pricingAndIssuer; }
    public void setPricingAndIssuer(PricingAndIssuer pricingAndIssuer) { this.pricingAndIssuer = pricingAndIssuer; }
    public RiskAndRating getRiskAndRating() { return riskAndRating; }
    public void setRiskAndRating(RiskAndRating riskAndRating) { this.riskAndRating = riskAndRating; }
    public MarketAndDistribution getMarketAndDistribution() { return marketAndDistribution; }
    public void setMarketAndDistribution(MarketAndDistribution marketAndDistribution) { this.marketAndDistribution = marketAndDistribution; }
    public List<Segment> getSegments() { return segments; }
    public void setSegments(List<Segment> segments) { this.segments = segments; }
}
