package com.example.instrument;

import java.util.List;

public class PricingAndIssuer {
    private List<Price> price;
    private List<Issuer> issuer;

    public List<Price> getPrice() { return price; }
    public void setPrice(List<Price> price) { this.price = price; }
    public List<Issuer> getIssuer() { return issuer; }
    public void setIssuer(List<Issuer> issuer) { this.issuer = issuer; }
}
