package com.example.instrument;

public class Rating {
    private String bondRating;
    private String moodyRating;
    private String fitchRating;
    private String spRating;
    private String fitchRatingDate;
    private String spRatingDate;
    private String moodyRatingDate;
    private Integer previousProductRiskRating;

    public String getBondRating() { return bondRating; }
    public void setBondRating(String bondRating) { this.bondRating = bondRating; }
    public String getMoodyRating() { return moodyRating; }
    public void setMoodyRating(String moodyRating) { this.moodyRating = moodyRating; }
    public String getFitchRating() { return fitchRating; }
    public void setFitchRating(String fitchRating) { this.fitchRating = fitchRating; }
    public String getSpRating() { return spRating; }
    public void setSpRating(String spRating) { this.spRating = spRating; }
    public String getFitchRatingDate() { return fitchRatingDate; }
    public void setFitchRatingDate(String fitchRatingDate) { this.fitchRatingDate = fitchRatingDate; }
    public String getSpRatingDate() { return spRatingDate; }
    public void setSpRatingDate(String spRatingDate) { this.spRatingDate = spRatingDate; }
    public String getMoodyRatingDate() { return moodyRatingDate; }
    public void setMoodyRatingDate(String moodyRatingDate) { this.moodyRatingDate = moodyRatingDate; }
    public Integer getPreviousProductRiskRating() { return previousProductRiskRating; }
    public void setPreviousProductRiskRating(Integer previousProductRiskRating) { this.previousProductRiskRating = previousProductRiskRating; }
}
