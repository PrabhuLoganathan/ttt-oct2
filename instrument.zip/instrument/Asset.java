package com.example.instrument;

public class Asset {
    private String assetClass;
    private String assetClassSubTotal;
    private String assetClassTotal;
    private String subAssetClass;

    public String getAssetClass() { return assetClass; }
    public void setAssetClass(String assetClass) { this.assetClass = assetClass; }
    public String getAssetClassSubTotal() { return assetClassSubTotal; }
    public void setAssetClassSubTotal(String assetClassSubTotal) { this.assetClassSubTotal = assetClassSubTotal; }
    public String getAssetClassTotal() { return assetClassTotal; }
    public void setAssetClassTotal(String assetClassTotal) { this.assetClassTotal = assetClassTotal; }
    public String getSubAssetClass() { return subAssetClass; }
    public void setSubAssetClass(String subAssetClass) { this.subAssetClass = subAssetClass; }
}
