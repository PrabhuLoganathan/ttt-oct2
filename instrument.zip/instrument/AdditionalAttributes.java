package com.example.instrument;

import java.util.Map;

public class AdditionalAttributes {
    private String newKeId;
    private String accrualStartDate;
    private Double yieldToWorst;
    private Integer daysToSettlement;
    private Double couponFrequencyYieldConvention;
    private String dayCountConvention;
    private Integer accrualRule;
    private String alternateCurrency;
    private Integer approvedForUnderlying;
    private Integer convertible;
    private Integer exchangeable;
    private Integer initialPublicOffering;
    private Integer liquidity;
    private Integer minimumTradeQuantity;
    private Integer minimumSubsequentInvestment;
    private Integer negotiability;
    private Integer oldProductTypePvb;
    private Integer preInvestmentCoolingRequired;
    private String countryCode;
    private String tapType;
    private Integer floater;
    private Double couponRateSpread;
    private String couponStartDate;
    private String priceScalingFactorChangeDate;
    private String couponEndDate;
    private String bbSecurityDomicile;
    private String bbIssuerDomicile;
    private String linkageStr;
    private Double prcYldYtmAsk;
    private Integer scbInstrumentType;
    private String openCloseEnded;
    private Asset asset;
    private Map<String, Object> creditQuality;
    private Map<String, Object> equityRegion;
    private Map<String, Object> fixedIncomeRegion;
    private Map<String, Object> fund;
    private Map<String, Object> settlement;

    public String getNewKeId() { return newKeId; }
    public void setNewKeId(String newKeId) { this.newKeId = newKeId; }
    public String getAccrualStartDate() { return accrualStartDate; }
    public void setAccrualStartDate(String accrualStartDate) { this.accrualStartDate = accrualStartDate; }
    public Double getYieldToWorst() { return yieldToWorst; }
    public void setYieldToWorst(Double yieldToWorst) { this.yieldToWorst = yieldToWorst; }
    public Integer getDaysToSettlement() { return daysToSettlement; }
    public void setDaysToSettlement(Integer daysToSettlement) { this.daysToSettlement = daysToSettlement; }
    public Double getCouponFrequencyYieldConvention() { return couponFrequencyYieldConvention; }
    public void setCouponFrequencyYieldConvention(Double couponFrequencyYieldConvention) { this.couponFrequencyYieldConvention = couponFrequencyYieldConvention; }
    public String getDayCountConvention() { return dayCountConvention; }
    public void setDayCountConvention(String dayCountConvention) { this.dayCountConvention = dayCountConvention; }
    public Integer getAccrualRule() { return accrualRule; }
    public void setAccrualRule(Integer accrualRule) { this.accrualRule = accrualRule; }
    public String getAlternateCurrency() { return alternateCurrency; }
    public void setAlternateCurrency(String alternateCurrency) { this.alternateCurrency = alternateCurrency; }
    public Integer getApprovedForUnderlying() { return approvedForUnderlying; }
    public void setApprovedForUnderlying(Integer approvedForUnderlying) { this.approvedForUnderlying = approvedForUnderlying; }
    public Integer getConvertible() { return convertible; }
    public void setConvertible(Integer convertible) { this.convertible = convertible; }
    public Integer getExchangeable() { return exchangeable; }
    public void setExchangeable(Integer exchangeable) { this.exchangeable = exchangeable; }
    public Integer getInitialPublicOffering() { return initialPublicOffering; }
    public void setInitialPublicOffering(Integer initialPublicOffering) { this.initialPublicOffering = initialPublicOffering; }
    public Integer getLiquidity() { return liquidity; }
    public void setLiquidity(Integer liquidity) { this.liquidity = liquidity; }
    public Integer getMinimumTradeQuantity() { return minimumTradeQuantity; }
    public void setMinimumTradeQuantity(Integer minimumTradeQuantity) { this.minimumTradeQuantity = minimumTradeQuantity; }
    public Integer getMinimumSubsequentInvestment() { return minimumSubsequentInvestment; }
    public void setMinimumSubsequentInvestment(Integer minimumSubsequentInvestment) { this.minimumSubsequentInvestment = minimumSubsequentInvestment; }
    public Integer getNegotiability() { return negotiability; }
    public void setNegotiability(Integer negotiability) { this.negotiability = negotiability; }
    public Integer getOldProductTypePvb() { return oldProductTypePvb; }
    public void setOldProductTypePvb(Integer oldProductTypePvb) { this.oldProductTypePvb = oldProductTypePvb; }
    public Integer getPreInvestmentCoolingRequired() { return preInvestmentCoolingRequired; }
    public void setPreInvestmentCoolingRequired(Integer preInvestmentCoolingRequired) { this.preInvestmentCoolingRequired = preInvestmentCoolingRequired; }
    public String getCountryCode() { return countryCode; }
    public void setCountryCode(String countryCode) { this.countryCode = countryCode; }
    public String getTapType() { return tapType; }
    public void setTapType(String tapType) { this.tapType = tapType; }
    public Integer getFloater() { return floater; }
    public void setFloater(Integer floater) { this.floater = floater; }
    public Double getCouponRateSpread() { return couponRateSpread; }
    public void setCouponRateSpread(Double couponRateSpread) { this.couponRateSpread = couponRateSpread; }
    public String getCouponStartDate() { return couponStartDate; }
    public void setCouponStartDate(String couponStartDate) { this.couponStartDate = couponStartDate; }
    public String getPriceScalingFactorChangeDate() { return priceScalingFactorChangeDate; }
    public void setPriceScalingFactorChangeDate(String priceScalingFactorChangeDate) { this.priceScalingFactorChangeDate = priceScalingFactorChangeDate; }
    public String getCouponEndDate() { return couponEndDate; }
    public void setCouponEndDate(String couponEndDate) { this.couponEndDate = couponEndDate; }
    public String getBbSecurityDomicile() { return bbSecurityDomicile; }
    public void setBbSecurityDomicile(String bbSecurityDomicile) { this.bbSecurityDomicile = bbSecurityDomicile; }
    public String getBbIssuerDomicile() { return bbIssuerDomicile; }
    public void setBbIssuerDomicile(String bbIssuerDomicile) { this.bbIssuerDomicile = bbIssuerDomicile; }
    public String getLinkageStr() { return linkageStr; }
    public void setLinkageStr(String linkageStr) { this.linkageStr = linkageStr; }
    public Double getPrcYldYtmAsk() { return prcYldYtmAsk; }
    public void setPrcYldYtmAsk(Double prcYldYtmAsk) { this.prcYldYtmAsk = prcYldYtmAsk; }
    public Integer getScbInstrumentType() { return scbInstrumentType; }
    public void setScbInstrumentType(Integer scbInstrumentType) { this.scbInstrumentType = scbInstrumentType; }
    public String getOpenCloseEnded() { return openCloseEnded; }
    public void setOpenCloseEnded(String openCloseEnded) { this.openCloseEnded = openCloseEnded; }
    public Asset getAsset() { return asset; }
    public void setAsset(Asset asset) { this.asset = asset; }
    public Map<String, Object> getCreditQuality() { return creditQuality; }
    public void setCreditQuality(Map<String, Object> creditQuality) { this.creditQuality = creditQuality; }
    public Map<String, Object> getEquityRegion() { return equityRegion; }
    public void setEquityRegion(Map<String, Object> equityRegion) { this.equityRegion = equityRegion; }
    public Map<String, Object> getFixedIncomeRegion() { return fixedIncomeRegion; }
    public void setFixedIncomeRegion(Map<String, Object> fixedIncomeRegion) { this.fixedIncomeRegion = fixedIncomeRegion; }
    public Map<String, Object> getFund() { return fund; }
    public void setFund(Map<String, Object> fund) { this.fund = fund; }
    public Map<String, Object> getSettlement() { return settlement; }
    public void setSettlement(Map<String, Object> settlement) { this.settlement = settlement; }
}
