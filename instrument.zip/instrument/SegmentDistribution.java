package com.example.instrument;

public class SegmentDistribution {
    private String country;
    private Integer segment;

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }
    public Integer getSegment() { return segment; }
    public void setSegment(Integer segment) { this.segment = segment; }
}
