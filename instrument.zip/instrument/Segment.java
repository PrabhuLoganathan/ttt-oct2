package com.example.instrument;

import java.util.List;

public class Segment {
    private String interestSchedule;
    private String priceCalculationRule;
    private String paymentFrequencyUnit;
    private List<SegmentDistribution> distributions;

    public String getInterestSchedule() { return interestSchedule; }
    public void setInterestSchedule(String interestSchedule) { this.interestSchedule = interestSchedule; }
    public String getPriceCalculationRule() { return priceCalculationRule; }
    public void setPriceCalculationRule(String priceCalculationRule) { this.priceCalculationRule = priceCalculationRule; }
    public String getPaymentFrequencyUnit() { return paymentFrequencyUnit; }
    public void setPaymentFrequencyUnit(String paymentFrequencyUnit) { this.paymentFrequencyUnit = paymentFrequencyUnit; }
    public List<SegmentDistribution> getDistributions() { return distributions; }
    public void setDistributions(List<SegmentDistribution> distributions) { this.distributions = distributions; }
}
