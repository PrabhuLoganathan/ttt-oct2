package com.example.instrument;

public class Distribution {
    private String country;
    private String segment;
    private Integer productRiskRatingCountry;
    private Integer channel;
    private Integer branch;
    private Integer distributionStatus;
    private Integer retailBondType;
    private String instrumentNameCountry;
    private String instrumentNameCountrySimplifiedChinese;
    private String instrumentNameCountryTraditionalChinese;
    private Integer professionalClientOrLocalEquivalentCountry;
    private Integer highYieldIndicator;
    private Integer authorizedBySfc;
    private Integer previousProductRiskRatingCountry;
    private String productRiskRatingCountryChangeDate;
    private String hkFundShareClass;
    private Integer lossAbsorbingCapacityCountry;
    private String openDate;
    private Integer complexCountry;

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }
    public String getSegment() { return segment; }
    public void setSegment(String segment) { this.segment = segment; }
    public Integer getProductRiskRatingCountry() { return productRiskRatingCountry; }
    public void setProductRiskRatingCountry(Integer productRiskRatingCountry) { this.productRiskRatingCountry = productRiskRatingCountry; }
    public Integer getChannel() { return channel; }
    public void setChannel(Integer channel) { this.channel = channel; }
    public Integer getBranch() { return branch; }
    public void setBranch(Integer branch) { this.branch = branch; }
    public Integer getDistributionStatus() { return distributionStatus; }
    public void setDistributionStatus(Integer distributionStatus) { this.distributionStatus = distributionStatus; }
    public Integer getRetailBondType() { return retailBondType; }
    public void setRetailBondType(Integer retailBondType) { this.retailBondType = retailBondType; }
    public String getInstrumentNameCountry() { return instrumentNameCountry; }
    public void setInstrumentNameCountry(String instrumentNameCountry) { this.instrumentNameCountry = instrumentNameCountry; }
    public String getInstrumentNameCountrySimplifiedChinese() { return instrumentNameCountrySimplifiedChinese; }
    public void setInstrumentNameCountrySimplifiedChinese(String instrumentNameCountrySimplifiedChinese) { this.instrumentNameCountrySimplifiedChinese = instrumentNameCountrySimplifiedChinese; }
    public String getInstrumentNameCountryTraditionalChinese() { return instrumentNameCountryTraditionalChinese; }
    public void setInstrumentNameCountryTraditionalChinese(String instrumentNameCountryTraditionalChinese) { this.instrumentNameCountryTraditionalChinese = instrumentNameCountryTraditionalChinese; }
    public Integer getProfessionalClientOrLocalEquivalentCountry() { return professionalClientOrLocalEquivalentCountry; }
    public void setProfessionalClientOrLocalEquivalentCountry(Integer professionalClientOrLocalEquivalentCountry) { this.professionalClientOrLocalEquivalentCountry = professionalClientOrLocalEquivalentCountry; }
    public Integer getHighYieldIndicator() { return highYieldIndicator; }
    public void setHighYieldIndicator(Integer highYieldIndicator) { this.highYieldIndicator = highYieldIndicator; }
    public Integer getAuthorizedBySfc() { return authorizedBySfc; }
    public void setAuthorizedBySfc(Integer authorizedBySfc) { this.authorizedBySfc = authorizedBySfc; }
    public Integer getPreviousProductRiskRatingCountry() { return previousProductRiskRatingCountry; }
    public void setPreviousProductRiskRatingCountry(Integer previousProductRiskRatingCountry) { this.previousProductRiskRatingCountry = previousProductRiskRatingCountry; }
    public String getProductRiskRatingCountryChangeDate() { return productRiskRatingCountryChangeDate; }
    public void setProductRiskRatingCountryChangeDate(String productRiskRatingCountryChangeDate) { this.productRiskRatingCountryChangeDate = productRiskRatingCountryChangeDate; }
    public String getHkFundShareClass() { return hkFundShareClass; }
    public void setHkFundShareClass(String hkFundShareClass) { this.hkFundShareClass = hkFundShareClass; }
    public Integer getLossAbsorbingCapacityCountry() { return lossAbsorbingCapacityCountry; }
    public void setLossAbsorbingCapacityCountry(Integer lossAbsorbingCapacityCountry) { this.lossAbsorbingCapacityCountry = lossAbsorbingCapacityCountry; }
    public String getOpenDate() { return openDate; }
    public void setOpenDate(String openDate) { this.openDate = openDate; }
    public Integer getComplexCountry() { return complexCountry; }
    public void setComplexCountry(Integer complexCountry) { this.complexCountry = complexCountry; }
}
