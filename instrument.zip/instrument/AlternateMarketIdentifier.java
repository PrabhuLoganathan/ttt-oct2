package com.example.instrument;

public class AlternateMarketIdentifier {
    private String isin;
    private String bloombergFigid;
    private String sedol;
    private String cusip;

    public String getIsin() { return isin; }
    public void setIsin(String isin) { this.isin = isin; }
    public String getBloombergFigid() { return bloombergFigid; }
    public void setBloombergFigid(String bloombergFigid) { this.bloombergFigid = bloombergFigid; }
    public String getSedol() { return sedol; }
    public void setSedol(String sedol) { this.sedol = sedol; }
    public String getCusip() { return cusip; }
    public void setCusip(String cusip) { this.cusip = cusip; }
}
