package com.example.instrument;

public class Issuer {
    private Long issueQuantity;
    private String isin;
    private String referenceCurrency;
    private String issuerInstrumentType;
    private String issuerHouse;
    private String legalName;
    private String taxCountry;
    private String issuerCode;
    private String issuerName;
    private Integer issuePrice;
    private String legalEntityIdentifier;
    private String issuerBloombergId;

    public Long getIssueQuantity() { return issueQuantity; }
    public void setIssueQuantity(Long issueQuantity) { this.issueQuantity = issueQuantity; }
    public String getIsin() { return isin; }
    public void setIsin(String isin) { this.isin = isin; }
    public String getReferenceCurrency() { return referenceCurrency; }
    public void setReferenceCurrency(String referenceCurrency) { this.referenceCurrency = referenceCurrency; }
    public String getIssuerInstrumentType() { return issuerInstrumentType; }
    public void setIssuerInstrumentType(String issuerInstrumentType) { this.issuerInstrumentType = issuerInstrumentType; }
    public String getIssuerHouse() { return issuerHouse; }
    public void setIssuerHouse(String issuerHouse) { this.issuerHouse = issuerHouse; }
    public String getLegalName() { return legalName; }
    public void setLegalName(String legalName) { this.legalName = legalName; }
    public String getTaxCountry() { return taxCountry; }
    public void setTaxCountry(String taxCountry) { this.taxCountry = taxCountry; }
    public String getIssuerCode() { return issuerCode; }
    public void setIssuerCode(String issuerCode) { this.issuerCode = issuerCode; }
    public String getIssuerName() { return issuerName; }
    public void setIssuerName(String issuerName) { this.issuerName = issuerName; }
    public Integer getIssuePrice() { return issuePrice; }
    public void setIssuePrice(Integer issuePrice) { this.issuePrice = issuePrice; }
    public String getLegalEntityIdentifier() { return legalEntityIdentifier; }
    public void setLegalEntityIdentifier(String legalEntityIdentifier) { this.legalEntityIdentifier = legalEntityIdentifier; }
    public String getIssuerBloombergId() { return issuerBloombergId; }
    public void setIssuerBloombergId(String issuerBloombergId) { this.issuerBloombergId = issuerBloombergId; }
}
