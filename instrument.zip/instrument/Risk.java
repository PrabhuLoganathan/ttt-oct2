package com.example.instrument;

public class Risk {
    private Integer productRiskRating;
    private String riskCurrency;
    private String riskCountry;
    private String riskNature;
    private String productRiskRatingChangeDate;
    private String ultimateParentCountryOfRisk;

    public Integer getProductRiskRating() { return productRiskRating; }
    public void setProductRiskRating(Integer productRiskRating) { this.productRiskRating = productRiskRating; }
    public String getRiskCurrency() { return riskCurrency; }
    public void setRiskCurrency(String riskCurrency) { this.riskCurrency = riskCurrency; }
    public String getRiskCountry() { return riskCountry; }
    public void setRiskCountry(String riskCountry) { this.riskCountry = riskCountry; }
    public String getRiskNature() { return riskNature; }
    public void setRiskNature(String riskNature) { this.riskNature = riskNature; }
    public String getProductRiskRatingChangeDate() { return productRiskRatingChangeDate; }
    public void setProductRiskRatingChangeDate(String productRiskRatingChangeDate) { this.productRiskRatingChangeDate = productRiskRatingChangeDate; }
    public String getUltimateParentCountryOfRisk() { return ultimateParentCountryOfRisk; }
    public void setUltimateParentCountryOfRisk(String ultimateParentCountryOfRisk) { this.ultimateParentCountryOfRisk = ultimateParentCountryOfRisk; }
}
